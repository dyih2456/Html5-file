# PS1 Memory Card 

A Pen created on CodePen.

Original URL: [https://codepen.io/Alansdead/pen/VYYwXOw](https://codepen.io/Alansdead/pen/VYYwXOw).

A 3D representation of a PS1 memory card (sort of) that continues to rotate

Interactive mouse movement: when you hover over the card, it pauses the automatic animations and follows your mouse movement